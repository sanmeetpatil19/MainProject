package worldclock;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Random;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import java.util.Date;


public class Basic {
      static WebDriver driver;
      static File f;
      static FileInputStream fis;
      static Properties prop;
       
      
//Opening the browser and navigating to the one cognizant website
      @BeforeTest
      @Test
      public void crossBrowsing() throws IOException {
    	  f=new File("C:\\Users\\2272763\\Downloads\\worldclock_Final\\worldclock\\src\\test\\resources\\datas\\Data.properties");
          fis=new FileInputStream(f);
          prop=new Properties();
          prop.load(fis);
          String url=prop.getProperty("url");
          String browser=prop.getProperty("browser");
//For Mozilla firefox browser          
    	  if(browser.equalsIgnoreCase("firefox")) {
    		  driver=new FirefoxDriver();
//To maximize the window
   		      driver.manage().window().maximize();
   		      driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
   		      System.out.println("FireFox driver is launched Successfully");
   		      System.out.println("-----------------------------------------------------------------------------");
//Navigating to the Be-Cognizant website   		      
   		      driver.get(url);  		  
   		      System.out.println("OneCognizant website is opened successfully" );
   		      System.out.println("-----------------------------------------------------------------------------");
   		      captureScreenshot();
    	  }
//For Chrome browser      	  
    	  else if(browser.equalsIgnoreCase("chrome")) {
    		  driver=new ChromeDriver();
//To maximize the window
    		  driver.manage().window().maximize();
   		      driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
   		      System.out.println("Chrome driver is launched Successfully");
   		      System.out.println("-----------------------------------------------------------------------------");
//Navigating to the Be-Cognizant website   
   		      driver.get(url);
   		      System.out.println("OneCognizant website is opened successfully" );
		      System.out.println("-----------------------------------------------------------------------------");
		      captureScreenshot();
    	  }
//For Edge browser 
    	  else if(browser.equalsIgnoreCase("edge")) {
    		  driver=new EdgeDriver();
//To maximize the window
   		      driver.manage().window().maximize();
   		      driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
   		      System.out.println("Edge driver is launched Successfully");
   		      System.out.println("-----------------------------------------------------------------------------");
//Navigating to the Be-Cognizant website   
   		      driver.get(url);
   		      System.out.println("OneCognizant website is opened successfully" );
		      System.out.println("-----------------------------------------------------------------------------");
		      captureScreenshot();
    	  }
//other than Mozilla firefox, chrome and edge
    	  else {
    		  System.out.println("Incorrect Browser");
    		  System.out.println("-----------------------------------------------------------------------------");
    	  }    	  
      }
      
     
      
//To collect the username and email id from the profile
      @Test(priority = 2)
      public void profile() throws InterruptedException, IOException {
    	  Thread.sleep(2000);
//Fetching the username from the profile   	  
    	  driver.findElement(By.xpath("//*[@id='O365_HeaderRightRegion']")).click();
    	  WebElement name=driver.findElement(By.id("mectrl_currentAccount_primary"));
    	  String fetchedname=name.getText();
    	  System.out.println("Name:"+fetchedname);
//Fetching the email-id from the profile       	  
    	  WebElement empid=driver.findElement(By.id("mectrl_currentAccount_secondary"));
    	  String emp=empid.getText();
    	  System.out.println("Email-id:"+emp);
    	  System.out.println("-----------------------------------------------------------------------------");
    	  captureScreenshot();
      }
      
      
//To check whether world clock is displayed or not
      @Test(priority = 3)
      public void clock() throws InterruptedException, IOException {
     	 driver.findElement(By.xpath("//*[@id='O365_HeaderRightRegion']")).click();
       	 driver.findElement(By.xpath("//*[@id='spPageCanvasContent']/div/div/div/div/div/div[5]")).click();
	     Thread.sleep(20000);	         
    	 WebElement clockDis=driver.findElement(By.xpath("//div[@class='ControlZone--control']/div/div/div/span[@role='heading']"));  
    	 captureScreenshot();
//Comparing the fetched result with the word World Clock
    	 Assert.assertEquals("World Clock", clockDis.getText(), "World Clock is Displayed");
      }
      
      
//To assert whether Bangalore, London and New York is displayed
      @Test(priority=4)
      public void cityDisplay() throws InterruptedException, IOException {
//User created list with cities name as items  
    	List<String> userCreatedCities = new ArrayList<String>();
    	userCreatedCities.add("Bangalore, India (IST)");
    	userCreatedCities.add("London, UK (BST)");
    	userCreatedCities.add("New York, NY (EST)");
    	int i=0;
//User created list to store the cities that is fetched on website   	
    	List<WebElement>cities=driver.findElements(By.xpath("//div[@role='heading']"));
    	System.out.println("Time Zones");
    	for(WebElement city: cities) {
    		  System.out.println(city.getText());
    		  Assert.assertEquals(userCreatedCities.get(i), city.getText());
    		  i++;
    	  } 
    	 captureScreenshot();
    	System.out.println("-----------------------------------------------------------------------------");
      }
      
     
//To check whether the system time is according to displayed bangalore time
	  @Test(priority = 5)
      public void sytemTime() throws IOException {
//Getting the system time		
    	     SimpleDateFormat formatter= new SimpleDateFormat("MM/dd/yyyy hh:mm ");
    	     Date date=new Date();
    	     
    	     String fullDate=formatter.format(date).toString();
//To proccess two digit time (10, 11 and 12)    	     
    	     if(fullDate.substring(11,12).equalsIgnoreCase("1")){
    		     String datee=fullDate.substring(1, 10);
        	     String timee=fullDate.substring(11, 16);
//To get the timings displayed on the Be.Cognizant website        	    
        	     WebElement time=driver.findElement(By.xpath("//*/div/div/div/div[2]/div/div/div/div/div/div[1]/div/div/div/div[2]/div[1]/span[1]"));
        
        	     WebElement  day=driver.findElement(By.xpath("//*/div/div/div/div[2]/div/div/div/div/div/div[1]/div/div/div/div[2]/div[2]/div[2]"));
        	     String timeee=time.getText();

    	         String dayyy=day.getText();

        	     dayyy=dayyy.substring(5, 14);
        	     
        	     System.out.println("System Time:"+formatter.format(date));
        	     System.out.println("System Time:"+timee+" = "+"Time on the Website:"+timeee);
        	     System.out.println("System Date:"+datee+" = " +"Date on the Website:"+dayyy);
        	     System.out.println("-----------------------------------------------------------------------------");     
        	     Assert.assertEquals(timee, timeee);
        	     Assert.assertEquals(datee, dayyy);   	   
    	     }
    	     else
    	     {
    	     String datee=fullDate.substring(1, 10);
    	     String timee=fullDate.substring(12, 16);
//To get the timings displayed on the Be.Cognizant website         	    
    	     WebElement time=driver.findElement(By.xpath("//*/div/div/div/div[2]/div/div/div/div/div/div[1]/div/div/div/div[2]/div[1]/span[1]"));
    
    	     WebElement  day=driver.findElement(By.xpath("//*/div/div/div/div[2]/div/div/div/div/div/div[1]/div/div/div/div[2]/div[2]/div[2]"));
    	     String timeee=time.getText();

	         String dayyy=day.getText();

    	     dayyy=dayyy.substring(5, 14);
    	     
    	     System.out.println("System Time:"+formatter.format(date));
    	     System.out.println("System Time:"+timee+" = "+"Time on the Website:"+timeee);
    	     System.out.println("System Date:"+datee+" = " +"Date on the Website:"+dayyy);
    	     System.out.println("-----------------------------------------------------------------------------");
    	     
    	     captureScreenshot();
    	     Assert.assertEquals(timee, timeee);
    	     Assert.assertEquals(datee, dayyy);
    	        	     
    	     }
      }
    
	
//To check whether the displayed time for London and New York is correct by verifing it by googling and asserting  
  	 @Test(priority = 6)
        public void verifyCountryTime() throws InterruptedException, IOException {
//getting the London time from Be Cognizant website 		 
      	  WebElement lon=driver.findElement(By.xpath("//*/div/div/div/div[2]/div/div/div/div/div/div[2]/div/div/div/div[2]/div[1]/span[1]"));
      	  WebElement timingLondon=driver.findElement(By.xpath("//*/div/div/div/div[2]/div/div/div/div/div/div[2]/div/div/div/div[2]/div[1]/span[2]"));
      	  String london=lon.getText();
      	  String timLondon=timingLondon.getText().toLowerCase();
      	  london=london+" "+timLondon;
      	  int londonTimeLen=london.length();
      	  System.out.println("London time on website:"+london);
//getting the Newyork time from Be Cognizant website       	
      	  WebElement ny=driver.findElement(By.xpath("//*/div/div/div/div[2]/div/div/div/div/div/div[3]/div/div/div/div[2]/div[1]/span[1]"));
      	  WebElement timingNY=driver.findElement(By.xpath("//*/div/div/div/div[2]/div/div/div/div/div/div[3]/div/div/div/div[2]/div[1]/span[2]"));
      	  String newyork=ny.getText();
      	  String timeNY=timingNY.getText().toLowerCase();
      	  newyork=newyork+" "+timeNY;
      	  int nyTimeLen=newyork.length();
      	  System.out.println("New York time on website:"+newyork);
//Navigating to Google website      	                                     
      	  driver.get("Https://www.google.com/");
//getting the London time from Google website      	  
      	  driver.findElement(By.name("q")).sendKeys("London Time");
      	  Thread.sleep(1000);
      	  
      	  driver.findElement(By.name("q")).sendKeys(Keys.ENTER);
      	  Thread.sleep(5000);
      	  
      	  WebElement londonGetTime=driver.findElement(By.xpath("//*[@id='rso']/div[1]/div/div/div/div/div/div[1]"));
      	  captureScreenshot();                      
      	  String londonGetTimeValidate=londonGetTime.getText()+" ";
      	  //To process the time in required formate
      	  String londonGetTimeValidate2, londonGetTimeValidate1;
      	  if(londonTimeLen==8) {
      		londonGetTimeValidate2=londonGetTimeValidate.substring(6,8) ;
      		londonGetTimeValidate1=londonGetTimeValidate.substring(0, 5);
      		londonGetTimeValidate=londonGetTimeValidate1+" "+londonGetTimeValidate2;
      		
      	  }
      	  else {
      		londonGetTimeValidate2=londonGetTimeValidate.substring(5,7) ;
      		londonGetTimeValidate1=londonGetTimeValidate.substring(0, 4);
    		londonGetTimeValidate=londonGetTimeValidate1+" "+londonGetTimeValidate2;
      	  }
    	 
      	  System.out.println("London time in google:"+londonGetTimeValidate);
      	  
      	  
      	  WebElement z=driver.findElement(By.name("q"));
      	  z.sendKeys(Keys.CONTROL, Keys.chord("a"));
      	  z.sendKeys(Keys.BACK_SPACE);
//getting the Newyork time from Google website      	
      	  z.sendKeys("New York Time");
      	  driver.findElement(By.name("q")).sendKeys(Keys.ENTER);                            
      	  WebElement newyorkGetTime=driver.findElement(By.xpath("//*[@id='rso']/div[1]/div/div/div/div/div/div[1]"));
      	  captureScreenshot();
      	  String newyorkGetTimeValidate=newyorkGetTime.getText()+" ";
      	  String newyorkGetTimeValidate2, newyorkGetTimeValidate1;
//To process the time in required formate
    	  if(nyTimeLen==8) {  		       
    		  newyorkGetTimeValidate2=newyorkGetTimeValidate.substring(6,8) ;    		    		      		     
    		  newyorkGetTimeValidate=newyorkGetTimeValidate.substring(0,5);    		    
    		  newyorkGetTimeValidate=newyorkGetTimeValidate+" "+newyorkGetTimeValidate2;
    		       
    	  }
    	  else {
    		  newyorkGetTimeValidate2=newyorkGetTimeValidate.substring(5,7) ;
    		  newyorkGetTimeValidate1=newyorkGetTimeValidate.substring(0,4);
    		  newyorkGetTimeValidate=newyorkGetTimeValidate1+" "+newyorkGetTimeValidate2;
    	  }
  	 
      	  System.out.println("New york time in google:"+newyorkGetTimeValidate); 
      	                    System.out.println("-----------------------------------------------------------------------------");
   	      Thread.sleep(3000);
   	      driver.navigate().back();
   	      Thread.sleep(2000);
   	      driver.navigate().back();
    	  Thread.sleep(2000);
   	      driver.navigate().back();
          Thread.sleep(2000);
      	  
      	  
      	  Assert.assertEquals(londonGetTimeValidate, london);
   	      Assert.assertEquals(newyorkGetTimeValidate, newyork);
   	      
        }

  	 
//To verify whether date and day is displayed correctly for bangalore
          @Test(priority = 7)
          public void timeDiffver() throws InterruptedException, IOException {
        	 Thread.sleep(2000);
           	 driver.findElement(By.xpath("//*[@id='spPageCanvasContent']/div/div/div/div/div/div[5]")).click();
  
        	 WebElement dateandday= driver.findElement(By.xpath("//div/div/div/div[2]/div/div/div/div/div/div[1]/div/div/div/div[2]/div[2]/div[2]"));
        	 String webWeekDay=dateandday.getText().substring(0,3);
        	 String webMonthDate=dateandday.getText().substring(5);
        	  
        	 if (webMonthDate.length()<=9) {
        	    webMonthDate="0"+webMonthDate;
        	 }
//To get the time from system
     	     Date date=new Date();
     	     SimpleDateFormat formatter= new SimpleDateFormat("E, MM/dd/yyyy");
     	     String strDate=formatter.format(date);
        	 String sysWeekDay=strDate.substring(0,3);
        	 String sysMonthDate=strDate.substring(5);

        	 Assert.assertEquals(sysWeekDay, webWeekDay);
     	     Assert.assertEquals(sysMonthDate, webMonthDate);
     	     System.out.println("Bangalore's day and date on website"+webWeekDay +" and "+webMonthDate);
     	     System.out.println("System's day and date on website"+sysWeekDay +" and "+sysMonthDate);
     	     captureScreenshot();
     	     System.out.println("-----------------------------------------------------------------------------");
          }
          
          
//To calculate the difference between Bangalore and London Time and to check the difference is correct or not
            @Test(priority = 8)
             public void difBangLon() throws ParseException, InterruptedException, IOException  {
            	Thread.sleep(2000);
              	 WebElement dif= driver.findElement(By.xpath("//*/div/div/div/div[2]/div/div/div/div/div/div[2]/div/div/div/div[2]/div[2]/div[1]"));
              	 String diff=dif.getText();
              	 
              	 ZoneId bangaloreZone = ZoneId.of("Asia/Kolkata");
                ZoneId londonZone = ZoneId.of("Europe/London");

                ZonedDateTime bangaloreTime = ZonedDateTime.now(bangaloreZone);
                ZonedDateTime londonTime = ZonedDateTime.now(londonZone);
                      
                      
                String bangtime=bangaloreTime.toString().substring(11, 19);
                String londtime=londonTime.toString().substring(11, 19);
                System.out.println("Bangalore Time:"+bangtime);
                
                System.out.println("London Time:"+londtime);
                      
                SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss");
                Date date1 = format.parse(bangtime);
                Date date2 = format.parse(londtime);
                // Difference in Milliseconds
                long diffInMs = date2.getTime() - date1.getTime();
                   
                long diffSeconds = diffInMs / 1000 % 60;
                long diffMinutes = diffInMs / (60 * 1000) % 60;
                long diffHours = diffInMs / (60 * 60 * 1000) % 24;
                   
                // System.out.format("Difference : %d hours, %d minutes, %d seconds",
                //       diffHours, diffMinutes, diffSeconds);
                String diffMinute=String.valueOf(diffMinutes).substring(1);
                String differenceTime=diffHours+"h "+diffMinute+"m"+" behind";
                differenceTime=differenceTime.substring(1);
                Assert.assertEquals(differenceTime, diff);
                System.out.println("Calculated time difference:"+differenceTime);
                System.out.println("Difference Time displayed on website:"+diff);
                System.out.println("-----------------------------------------------------------------------------");
                }
             
   
   
     
//To load the hot apps menu completely
      @Test(priority = 10)
      public void hotAppsMore() throws InterruptedException, IOException{
//To click on One-Cognizant     
          driver.findElement(By.xpath("//*/div/div/div/div/div/div[2]/div/div/div/div/div/div/div/div/div[1]/div/div/div/a/div")).click();
    	  Thread.sleep(10000);
    	  JavascriptExecutor js=(JavascriptExecutor)driver;
    	  List<String> tabs=new ArrayList<String>(driver.getWindowHandles());
    	  
    	  driver.switchTo().window(tabs.get(1));
    	  Thread.sleep(10000);
//To scroll down
    	  js.executeScript("window.scrollBy(0, 1000)");
    	  captureScreenshot();
    	  driver.findElement(By.xpath("//*[@id='div_hotappscontainer']/div/div[2]/div/div[3]/div[1]")).click();	  
      }
      
      
// To check whether all alphabets are displayed and enabled 
     @Test(priority=11)
      public void hotappsss() throws InterruptedException, IOException {
    	  Thread.sleep(2000);
    	  List<WebElement> alpha=new ArrayList<WebElement>();
    	  alpha=driver.findElements(By.xpath("/html/body/div[2]/div[5]/div[2]/div[2]/div[1]/div/div/div[2]/div"));
    	  System.out.println("Alphabets displayed(visible) on website:");
//To display the alphabets visible on the page
      	  for(WebElement alpha1:alpha) {
      		
          System.out.println(alpha1.getText());
         
    	  }
      	 captureScreenshot();
      	 System.out.println("-----------------------------------------------------------------------------");
      	 char[] alp= {'@', 'A', 'B', 'C', 'D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','#'};
      	 
      	 for(int i=1;i<28;i++ ) {
      		boolean enabled=driver.findElement(By.xpath("/html/body/div[2]/div[5]/div[2]/div[2]/div[1]/div/div/div[2]/div/div["+i+"]")).isEnabled();
      
      		Thread.sleep(2000);
//To check whether alphabet is enabled or not
      		if(enabled) {
      			char selectedAlph=alp[i];
      			System.out.println(selectedAlph+" is enabled");
      		}else {
      			i++;
      		}
      		
      	 }
      	 System.out.println("-----------------------------------------------------------------------------");
      }
      
     
// To click on an alphabet using random number generator and click on that alphabet and to display all the apps starting with that alphabet   
     @Test(priority = 12)
      public void appsWithAlp() throws InterruptedException, IOException {
//Generate random number for selecting the alphabet
    	  Random random=new Random();
    	  int randomNumber=random.nextInt(28);
    	  WebElement randomNum= driver.findElement(By.xpath("/html/body/div[2]/div[5]/div[2]/div[2]/div[1]/div/div/div[2]/div/div["+randomNumber+"]"));
    	  System.out.println("Alphabet selected is: "+randomNum.getText());
    	  System.out.println("-----------------------------------------------------------------------------");
    	  String selectedAlph=randomNum.getText(); 
    	  
    	  char[] alp= {'@', 'A', 'B', 'C', 'D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','#'};
    	 
    	  int index= new String(alp).indexOf(selectedAlph);
    

    	  if(index==24) {
    		 System.out.println("No Apps By "+selectedAlph+" letter");
    	  }
    	  else {
    	    driver.findElement(By.xpath("//*[@id='divAppstoreContainer']/div[1]/div/div/div[2]/div/div["+index+"]")).click();
    	    Thread.sleep(2000);
//To store all the apps starting with selected alphabet
    	    List<WebElement> apps=new ArrayList<WebElement>();
    	    apps=driver.findElements(By.xpath("//*[@id='div_appFilteredList']/div"));
    	    captureScreenshot();
    	    System.out.println("List of apps starting by "+randomNum.getText()+" is/are as follows:");
    	    System.out.println(apps.get(0).getText());
    	    int sizeOf=apps.size();
    	            System.out.println(sizeOf);
//To display the list of apps starting with the selected alphabet          
    	    for(int i=1; i<=sizeOf;i++ ) {
    		  
        		System.out.println(driver.findElement(By.xpath("//*[@id='div_appFilteredList']/div/div["+i+"]/div/div[4]/div")).getText());
        		   
        		Thread.sleep(2000);
    	     }
    	  }
      }
 //To Log the executed data into a output file        
     @Test(priority = 1)
     public void output() throws FileNotFoundException {
    	 System.setOut(new PrintStream(new FileOutputStream("Output/output.txt")));
    	 System.out.println("Out put is stored in the output.txt in console output folder");
     }
     
// Method to take screenshot    
     public static void captureScreenshot() throws IOException 
     {
         String timeStamp= new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
         TakesScreenshot screen=(TakesScreenshot)driver;
         File source=screen.getScreenshotAs(OutputType.FILE);
         FileUtils.copyFile(source, new File("Screenshot/"+timeStamp+"_screenshot.png"));
         System.out.println("Screenshot is successfully captured");
     }
       
// To close all the opened windows   
      @AfterTest
      @Test
      public void closee() {
    	  System.out.println("-----------------------------------------------------------------------------");
    	  System.out.println("Browser is closed successfully");
    	  driver.quit();
      }  
}
